﻿(function (angular) {
    var url = 'http://test.sandlife.com.cn/index.php/openapi/appapi_route/api';
    /***手机号验证***/
    var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1}))+\d{8})$/;
    /***MD5签名***/
    function md5Fun(dic) {
        var dicdic = '';
        var sdic = Object.keys(dic).sort();
        for (ki in sdic) {
            dicdic += sdic[ki] + dic[sdic[ki]]
        }//76392801
        return (hex_md5(hex_md5(dicdic).toUpperCase() + 88888888)).toUpperCase();
    }

    /***时间戳***/
    function timestamp() {
        var datetime = Date.parse(new Date());
        return datetime;
    }

    /***时间戳转时间***/
    function getLocalTimeDate(nS) {
        var timestamp = nS;
        ;
        var d = new Date(timestamp * 1000);    //根据时间戳生成的时间对象
        var date = (d.getFullYear()) + "-" +
            (d.getMonth() + 1) + "-" +
            (d.getDate());
        return date;
    }

    function getLocalTime(nS) {
        var timestamp = nS;
        var d = new Date(timestamp * 1000);    //根据时间戳生成的时间对象
        var date = "<span>" + (d.getFullYear()) + "-" +
            (d.getMonth() + 1) + "-" +
            (d.getDate()) + " </span><br/><span>" +
            (d.getHours()) + ":" +
            (d.getMinutes()) + ":" +
            (d.getSeconds()) + "</span>";
        return date;
    }

    /***取对象长度**/
    function getJsonLength(jsonData) {
        var jsonLength = 0;
        for (var item in jsonData) {
            jsonLength++;

        }
        return jsonLength;
    }

    /***微信支付**/
    function wechatpay(id) {
        location.href = 'http://www.sandlife.com.cn/weixin/pay/runtime.php?order_id=' + id + '&paytype=appapi';
    }

    /***浏览器版本号**/
    var br = navigator.userAgent.toLowerCase();
    var browserVer = (br.match(/.+(?:rv|it|ra|ie)[\/: ]([\d.]+)/) || [0, '0'])[1];

    /***Obj合并，post参数**/
    function extendObj(o, n) {
        for (var p in n) {
            if (n.hasOwnProperty(p) && (!o.hasOwnProperty(p) ))
                o[p] = n[p];
        }
        return o;
    };
//rsa加密
    function encrypt(str) {
        // public key notice the '\'
        var pem = '-----BEGIN PUBLIC KEY-----MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC2Z3z3tI5NTk9UAFvhsJnjasanaurn6HzZo7uze+Nqt8e9z8MvekTKc/x5vnKPpt78XjAL7/VCdMx3hzOvxHl3o6YsM6LTimt02VMykxydUzgN0AqPlrliFgKa0v3AWX7Qy/IJoeExwkbgKcOZgm5qOyn+tz0zLEhH2cG0YlIqcwIDAQAB-----END PUBLIC KEY-----';
        var key = RSA.getPublicKey(pem);
        return RSA.encrypt(str, key);
    }

    function httpurl(dic2) {
        var dic1 = {
            'version': '400',
            "app_id": '001',
            'charset': 'UTF-8',
            'format': 'json',
            'deviceType': '0003',
            'deviceID': browserVer,
            'date': timestamp()
        };
        var dic = extendObj(dic1, dic2);
        dic.sign = md5Fun(dic);
        var dicdic = '';
        //字典排序
        var sdic = Object.keys(dic).sort();
        for (ki in sdic) {
            dicdic += sdic[ki] + '=' + dic[sdic[ki]] + '&';
        }
        dicdic = base64encode(utf16to8(dicdic.substring(0, dicdic.length - 1)));
        var encrytext = [];
        for (var i = 0; i < (parseInt(dicdic.length / 110) + 1); i++) {
            encrytext[i] = encrypt(dicdic.substring(0 + i * 110, 110 * (i + 1)));
        }
        var httpurldata = {
            url: url,
            method: 'POST',
            data: encrytext
        }
        return httpurldata;
    }

    /***字符串插入字符**/
    function insert_flg(str, flg, sn) {
        var newstr = "";
        for (var i = 0, j = 0; i < str.length; i += sn, j = 1) {
            var tmp = str.substring(i, i + sn);
            if (j == 0) {
                newstr += tmp + flg;
            } else {
                newstr += tmp;
            }

        }
        return newstr;
    }

    /***订单状态**/
    function status_sub(pay_status, receive_status) {
        if (receive_status == undefined) {
            return pay_status;
        } else {
            if (receive_status == '0') {
                return pay_status + '<br/> 未处理';
            } else if (receive_status == '1') {
                return pay_status + '<br/> 已处理';
            } else if (receive_status == '2') {
                return pay_status + '<br/> 处理失败';
            } else if (receive_status == '3') {
                return pay_status + '<br/> 处理中';
            } else {
                return pay_status + '<br/> 处理中';
            }
        }

    }

    function getState(pay_status, status, receive_status) {
        if (status == 'dead') {
            return '已作废';
        } else if (pay_status == '0') {
            return '等待付款';
        } else if (pay_status == '1') {
            pay_status = '已支付';
            return status_sub(pay_status, receive_status)

        } else if (pay_status == '2') {
            pay_status = '已付款到担保方';
            return status_sub(pay_status, receive_status)

        } else if (pay_status == '3') {
            return '部分付款';
        } else if (pay_status == '4') {
            pay_status = '等待退款';
            return status_sub(pay_status, receive_status)

        } else if (pay_status == '5') {
            pay_status = '已退款';
            return status_sub(pay_status, receive_status)

        }
    }

    /**字符限定长度*/
    function cutString(str, len) {
        //length属性读出来的汉字长度为1
        if (str.length * 2 <= len) {
            return str;
        }
        var strlen = 0;
        var s = "";
        for (var i = 0; i < str.length; i++) {
            s = s + str.charAt(i);
            if (str.charCodeAt(i) > 128) {
                strlen = strlen + 2;
                if (strlen >= len) {
                    return s.substring(0, s.length - 1) + "...";
                }
            } else {
                strlen = strlen + 1;
                if (strlen >= len) {
                    return s.substring(0, s.length - 2) + "...";
                }
            }
        }
        return s;
    }


    function HttpInterceptor($q) {
        return {
            request: function (config) {

                return config;
            },
            requestError: function (err) {

                return $q.reject(err);
            },
            response: function (res) {

                return res;
            },
            responseError: function (err) {

                if (-1 === err.status) {
                    // 远程服务器无响应
                } else if (500 === err.status) {
                    // 处理各类自定义错误
                } else if (501 === err.status) {
                    // ...
                }
                return $q.reject(err);
            }
        };
    }


    angular.module('sandLifeApp', ['ionic'])
        //请求以及响应拦截器
        .factory('HttpInterceptor', ['$q', HttpInterceptor])
        //隐藏底层菜单
        .directive('hideTabs', function ($rootScope) {
            return {
                restrict: 'A',
                link: function (scope, element, attributes) {
                    scope.$on('$ionicView.beforeEnter', function () {
                        scope.$watch(attributes.hideTabs, function (value) {
                            $rootScope.hideTabs = value;
                        });
                    });

                    scope.$on('$ionicView.beforeLeave', function () {
                        scope.$watch(attributes.hideTabs, function (value) {
                            $rootScope.hideTabs = 'tabs-item-hide';
                        });
                        scope.$watch('$destroy', function () {
                            $rootScope.hideTabs = false;
                        })
                    });
                }
            };
        })
        //下拉刷新
        .run(function ($ionicPlatform) {
            $ionicPlatform.ready(function () {
                // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
                // for form inputs)
                if (window.cordova && window.cordova.plugins.Keyboard) {
                    cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
                }
                if (window.StatusBar) {
                    StatusBar.styleDefault();
                }
            });
        })
        .config(function ($stateProvider, $urlRouterProvider, $ionicConfigProvider, $httpProvider) {
            $ionicConfigProvider.platform.ios.tabs.style('standard');
            $ionicConfigProvider.platform.ios.tabs.position('bottom');
            $ionicConfigProvider.platform.android.tabs.style('standard');
            $ionicConfigProvider.platform.android.tabs.position('standard');

            $ionicConfigProvider.platform.ios.navBar.alignTitle('center');
            $ionicConfigProvider.platform.android.navBar.alignTitle('center');

            $ionicConfigProvider.platform.ios.backButton.previousTitleText('').icon('ion-ios-arrow-thin-left');
            $ionicConfigProvider.platform.android.backButton.previousTitleText('').icon('ion-android-arrow-back');

            $ionicConfigProvider.platform.ios.views.transition('ios');
            $ionicConfigProvider.platform.android.views.transition('android');

            $ionicConfigProvider.backButton.text("");
            $ionicConfigProvider.backButton.previousTitleText(false);

            $httpProvider.interceptors.push(HttpInterceptor);

            $httpProvider.defaults.headers.put['Content-Type'] = 'application/x-www-form-urlencoded';
            $httpProvider.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';

            // Override $http service's default transformRequest
            $httpProvider.defaults.transformRequest = [function (data) {
                /**
                 * The workhorse; converts an object to x-www-form-urlencoded serialization.
                 * @param {Object} obj
                 * @return {String}
                 * 解决php json数据传输问题
                 */
                var param = function (obj) {
                    var query = '';
                    var name, value, fullSubName, subName, subValue, innerObj, i;

                    for (name in obj) {
                        value = obj[name];

                        if (value instanceof Array) {
                            for (i = 0; i < value.length; ++i) {
                                subValue = value[i];
                                fullSubName = name + '[' + i + ']';
                                innerObj = {};
                                innerObj[fullSubName] = subValue;
                                query += param(innerObj) + '&';
                            }
                        } else if (value instanceof Object) {
                            for (subName in value) {
                                subValue = value[subName];
                                fullSubName = name + '[' + subName + ']';
                                innerObj = {};
                                innerObj[fullSubName] = subValue;
                                query += param(innerObj) + '&';
                            }
                        } else if (value !== undefined && value !== null) {
                            query += encodeURIComponent(name) + '='
                                + encodeURIComponent(value) + '&';
                        }
                    }

                    return query.length ? query.substr(0, query.length - 1) : query;
                };

                return angular.isObject(data) && String(data) !== '[object File]'
                    ? param(data)
                    : data;
            }];

            //路由
            $stateProvider
                .state('tabs', {
                    url: "/tab",
                    abstract: true,
                    templateUrl: "templates/tabs.html",
                    controller: 'tabsCtrl'
                })
                .state('tabs.home', {
                    url: "/home",
                    views: {
                        'home-tab': {
                            templateUrl: "templates/home.html",
                            controller: 'homeCtrl'
                        }
                    }

                })
                .state('tabs.sandBeTo', {
                    url: "/sandBeTo",
                    views: {
                        'person-tab': {
                            templateUrl: "templates/sandBeTo.html",
                            controller: 'sandBeToCtrl'
                        }
                    }

                })
                .state('tabs.currency', {
                    url: "/currency",
                    views: {
                        'person-tab': {
                            templateUrl: "templates/account/currency.html",
                            controller: 'currencyCtrl'
                        }
                    }

                })
                .state('tabs.orderDetailSub', {
                    url: "/orderDetailSub",
                    cache: false,
                    views: {
                        'person-tab': {
                            templateUrl: "templates/order/orderDetailSub.html",
                            controller: 'orderDetailSubCtrl'
                        }
                    }

                })
                .state('tabs.orderDetailSubHome', {
                    url: "/orderDetailSubHome",
                    cache: false,
                    views: {
                        'home-tab': {
                            templateUrl: "templates/order/orderDetailSub.html",
                            controller: 'orderDetailSubCtrl'
                        }
                    }

                })
                .state('tabs.sandCoin', {
                    url: "/sandCoin",
                    views: {
                        'person-tab': {
                            templateUrl: "templates/account/sandCoin.html",
                            controller: 'sandCoinCtrl'
                        }
                    }

                })
                .state('tabs.super', {
                    url: "/super",
                    views: {
                        'person-tab': {
                            templateUrl: "templates/account/super.html",
                            controller: 'superCtrl'
                        }
                    }

                })
                .state('tabs.around', {
                    url: "/around",
                    views: {
                        'around-tab': {
                            templateUrl: "templates/around.html"
                        }
                    }
                })
                .state('tabs.person', {
                    url: "/person",
                    views: {
                        'person-tab': {
                            templateUrl: "templates/person.html",
                            controller: 'personCtrl'
                        }
                    }
                })

                .state('tabs.qiangsheng', {
                    url: "/qiangsheng",
                    views: {
                        'person-tab': {
                            templateUrl: "templates/order/qiangsheng.html",
                            controller: 'qiangshengOrderCtrl'
                        }
                    }
                })
                .state('tabs.toBePay', {
                    url: "/toBePay",
                    cache: false,
                    views: {
                        'person-tab': {
                            templateUrl: "templates/toBePay.html",
                            controller: 'toBePayCtrl'
                        }
                    }
                })
                .state('tabs.waterOrder', {
                    url: "/waterOrder",
                    cache: false,
                    views: {
                        'person-tab': {
                            templateUrl: "templates/order/waterOrder.html",
                            controller: 'waterOrderCtrl'
                        }
                    }
                })
                .state('tabs.waterOrderHome', {
                    url: "/waterOrderHome",
                    cache: false,
                    views: {
                        'home-tab': {
                            templateUrl: "templates/order/waterOrder.html",
                            controller: 'waterOrderCtrl'
                        }
                    }
                })
                .state('tabs.accountDetail', {
                    url: "/accountDetail",
                    cache: false,
                    views: {
                        'person-tab': {
                            templateUrl: "templates/accountDetail.html",
                            controller: 'accountDetailCtrl'
                        }
                    }
                })
                .state('tabs.phoneCharge', {
                    url: "/phoneCharge",
                    views: {
                        'home-tab': {
                            templateUrl: "templates/phoneCharge.html",
                            controller: 'phoneChargeCtrl'
                        }
                    }
                })
                .state('tabs.phoneChargePerson', {
                    url: "/phoneChargePerson",
                    views: {
                        'person-tab': {
                            templateUrl: "templates/phoneCharge.html",
                            controller: 'phoneChargeCtrl'
                        }
                    }
                })
                .state('tabs.accountManage', {
                    url: "/accountManage",
                    views: {
                        'person-tab': {
                            templateUrl: "templates/accountManage.html",
                            controller: 'accountManageCtrl'
                        }
                    }
                })
                .state('tabs.orderDetail', {
                    url: "/orderDetail",
                    views: {
                        'person-tab': {
                            templateUrl: "templates/orderDetail.html",
                            controller: 'orderDetailCtrl'
                        }
                    }
                })
                .state('tabs.coupon', {
                    url: "/coupon",
                    views: {
                        'person-tab': {
                            templateUrl: "templates/coupon.html",
                            controller: 'couponCtrl'
                        }
                    }
                })
                .state('tabs.couponDetail', {
                    url: "/couponDetail",
                    cache: false,
                    views: {
                        'person-tab': {
                            templateUrl: "templates/couponDetail.html",
                            controller: 'couponDetailCtrl'
                        }
                    }
                })
                .state('tabs.oilCharge', {
                    url: "/oilCharge",
                    views: {
                        'home-tab': {
                            templateUrl: "templates/oilCharge.html",
                            controller: 'oilChargeCtrl'
                        }
                    }
                })
                .state('tabs.lifePay', {
                    url: "/lifePay",
                    views: {
                        'home-tab': {
                            templateUrl: "templates/lifePay.html",
                            controller: 'lifePayCtrl'
                        }
                    }
                })
                .state('tabs.lifePayPerson', {
                    url: "/lifePayPerson",
                    views: {
                        'person-tab': {
                            templateUrl: "templates/lifePay.html",
                            controller: 'lifePayCtrl'
                        }
                    }
                })
                .state('tabs.oilChargePerson', {
                    url: "/oilChargePerson",
                    views: {
                        'person-tab': {
                            templateUrl: "templates/oilCharge.html",
                            controller: 'oilChargeCtrl'
                        }
                    }
                })

                .state('tabs.water', {
                    url: "/water",
                    cache: false,
                    views: {
                        'home-tab': {
                            templateUrl: "templates/water.html",
                            controller: 'waterCtrl'
                        }
                    }
                })
                .state('tabs.waterPerson', {
                    url: "/waterPerson",
                    cache: false,
                    views: {
                        'person-tab': {
                            templateUrl: "templates/water.html",
                            controller: 'waterCtrl'
                        }
                    }
                })
                .state('tabs.wallet', {
                    url: "/wallet",
                    views: {
                        'person-tab': {
                            templateUrl: "templates/wallet.html",
                            controller: 'walletCtrl'
                        }
                    }
                });

            $urlRouterProvider.otherwise("/tab/home");


        })
        //http服务
        .service('httpService', ['$http', '$q', function ($http, $q, $scope) {
            return {
                getHttpService: function (dic) {
                    // 如果已存在则直接返回
                    /*if(httpService){
                     return $q.when(httpService);
                     }*/
                    return $http(httpurl(dic)).then(function (res) {
                        // 把数据存到server中并返回
                        if (res.data.resultCode == '0000') {
                            return res.data;
                        } else {
                            alert(res.data.resultMessage);
                        }
                    }, function (res) {
                        alert(res.statusText)

                    })
                }
            }
        }])
        .directive("sandlifeappDirective", function () {
            return {
                restrict: "E",
                template: '<div class="pop" ng-show="popShow" ng-click="popHide()"> <div class="popcontent" >{{popContent}}</div> </div>' +
                    '<div class="loadingBox" ng-show="loadingBox" >   <ion-spinner icon="ios"  ></ion-spinner></div>',
                link: function (scope) {
                    scope.popAlert = function (content) {
                        scope.popShow = true;
                        scope.popContent = content;
                    }
                    scope.popHide = function () {
                        scope.popShow = false;
                        scope.loadingBox = false;
                    }
                }
            };
        })
        .controller('tabsCtrl', function ($scope) {
            $scope.toUrl = function (url) {
                if (url == 'home') {
                    sessionStorage.Home = 'Home';
                    location.href = "#/tab/home";
                } else if (url == 'person') {
                    sessionStorage.Home = '';
                    location.href = "#/tab/person";
                }
            }
        })
        .controller('homeCtrl', function ($scope, $ionicSlideBoxDelegate, $http, httpService, $interval) {
            $scope.menu1 = [], $scope.menu2 = [];
            var slideInterval;
            sessionStorage.Home = 'Home';
            $scope.model = {
                activeIndex: 0,
                activeNavIndex: 0,
                pageClick: function (index) {
                    $scope.model.activeIndex = index;
                },
                pageNavClick: function (index) {
                    $scope.model.activeNavIndex = index;
                },

            }
            $scope.toLink = function (link, title) {
                if (title == '话费充值') {
                    location.href = "#/tab/phoneCharge";
                } else if (title == '油卡充值') {
                    location.href = "#/tab/oilCharge";
                } else if (title == '生活缴费') {
                    location.href = "#/tab/lifePay";
                } else if (title == 'link_url') {
                    location.href =link;
                } else {
                    location.href =  link + 'deviceType/0003';
                }

            }
            $scope.toLinkCash = function (id) {
                location.href ='http://test.sandlife.com.cn/index.php/openapi/appapi_token/check_code/trans_type/0011/id/' + id + '/deviceType/0003';
            }

            var dic = {
                'apiName': 'weixin.islogin'
            };
            var dicc = {
                'apiName': 'frontpage.get'
            };
            $http(httpurl(dic))
                .success(function (data) {
                    if (data.resultCode == "0000") {
                        if (data.result.code == "00008") {
                            location.href = 'http://test.sandlife.com.cn/index.php/openapi/weixin_member/verify_login?redirect_uri=' + encodeURIComponent(location.href);
                        } else if (data.result.code == "00000") {
                            sessionStorage.usermobile = data.result.usermobile;
                            sessionStorage.useruname = data.result.username;
                            sessionStorage.headimgurl = data.result.headimgurl;
                            $scope.loadingBox = true;
                            success_data(dicc);
                        }

                    } else {
                        $scope.popAlert(data.resultMessage);
                    }
                })
                .error(function (data, status, headers, config, statusText) {
                    $scope.popAlert(statusText);
                })
            function success_data(dicc) {
                $http(httpurl(dicc))
                    .success(function (data) {
                        $scope.loadingBox = false;
                        if (data.result.carousel.length == '0') {
                            $scope.slidePic = [
                                {
                                    "pic_path": "http://test.sandlife.com.cn/public/images/05/62/8c/841de4ce43e1cf253553348e2ad18096.jpg",
                                    "link_url": "http://www.sandlife.com.cn/"
                                },
                                {
                                    "pic_path": "http://test.sandlife.com.cn/public/images/42/cf/ab/0e9f185ed6bc1b06cca4ee5e7c07b483.jpg",
                                    "link_url": "http://www.baidu.com.cn/"
                                },
                                {
                                    "pic_path": "http://test.sandlife.com.cn/public/images/42/cf/ab/0e9f185ed6bc1b06cca4ee5e7c07b483.jpg",
                                    "link_url": "http://www.baidu.com.cn/"
                                }
                            ]
                        } else {
                            $scope.slidePic = data.result.carousel;
                        }
                        slideInterval= $interval(function () {
                            if ($scope.model.activeIndex == ($scope.slidePic.length - 1)) {
                                $scope.model.activeIndex = 0;
                            } else {
                                $scope.model.activeIndex++;
                            }
                        }, 3000);
                        $scope.slideAdv = data.result.adv;
                        $scope.cashcoupon = data.result.cashcoupon;
                        $scope.menu1 = [], $scope.menu2 = [];
                        $ionicSlideBoxDelegate.update();
                        for (var i = 0; i < 8; i++) {
                            $scope.menu1[i] = data.result.menu[i];
                            $scope.menu1[i].url = data.result.menu[i].url.substring(0, data.result.menu[i].url.length - 5);
                        }
                        for (var i = 8, j = 0; i < data.result.menu.length; i++, j++) {
                            $scope.menu2[j] = data.result.menu[i];
                            $scope.menu2[j].url = data.result.menu[i].url.substring(0, data.result.menu[i].url.length - 5);
                        }

                        for (var i = 0; i < data.result.cashcoupon.length; i++) {
                            $scope.cashcoupon[i].price = parseFloat($scope.cashcoupon[i].price).toFixed(2);
                            $scope.cashcoupon[i].mktprice = parseFloat($scope.cashcoupon[i].mktprice).toFixed(2);

                        }
                        $scope.$broadcast('scroll.refreshComplete');
                    })
                    .error(function (data, status, headers, config) {
                        $scope.popAlert(status)
                    })
            }
            $scope.doRefresh = function () {
                $scope.menu1 = [], $scope.menu2 = [];
                $interval.cancel(slideInterval);
                success_data(dicc);
            };
        })
        .controller('personCtrl', function ($scope) {
            $scope.popShow = false;
            sessionStorage.Home = '';
            $scope.username = sessionStorage.useruname;
            $scope.mobile = sessionStorage.usermobile.substr(0, 3) + "****" + sessionStorage.usermobile.substr(7);
            if (sessionStorage.headimgurl == undefined) {
                $scope.headimgurl = 'img/person/pic-mrtx@3x.png';
            } else {
                $scope.headimgurl = sessionStorage.headimgurl;
            }
            $scope.sandBaoClick = function (x) {
                if (sessionStorage.sandbao_status == '1') {
                    $scope.popAlert('您还未开通久彰宝！');
                } else {
                    if (x == 1) {
                        location.href = "#/tab/currency";
                    } else if (x == 2) {
                        location.href = "#/tab/super";
                    } else if (x == 3) {
                        location.href = "#/tab/sandCoin";
                    } else if (x == 4) {
                        location.href = "#/tab/wallet";
                    }
                }

            }
            $scope.toUrl = function (x) {
                sessionStorage.orderType = x;
                location.href = '#/tab/toBePay';

            }
        })
        .controller('lifePayCtrl', function ($scope) {
            if (sessionStorage.Home == 'Home') {
                $scope.indexPageName = '首页';
                $scope.indexPage = 'home';
            } else if (sessionStorage.Home == '') {
                $scope.indexPageName = '我的';
                $scope.indexPage = 'person';
            }
            $scope.toUrl = function (type) {
                sessionStorage.lifePayType = type;
                if (sessionStorage.Home == 'Home') {
                    location.href = '#/tab/water';
                } else if (sessionStorage.Home == '') {
                    location.href = '#/tab/waterPerson';
                }
            }
        })
        .controller('waterOrderCtrl', function ($scope, $http) {
            $scope.moredata = false;
            $scope.state = [];
            $scope.data = [];
            if (sessionStorage.Home == 'Home') {
                $scope.indexPageName = '首页';
                $scope.indexPage = 'home';

            } else if (sessionStorage.Home == '') {
                $scope.indexPageName = '我的';
                $scope.indexPage = 'person';
            }
            var orderType = sessionStorage.orderType;
            if (orderType == 'water') {
                $scope.orderTypeTitle = '水费';
                $scope.img_icon = "img/home/pic_sfy@3x.png";
            } else if (orderType == 'electricity') {
                $scope.orderTypeTitle = '电费';
                $scope.img_icon = "img/home/pic_dfy@3x.png";
            } else if (orderType == 'gas') {
                $scope.orderTypeTitle = '煤气费';
                $scope.img_icon = "img/home/pic_mqfy@3x.png";
            } else if (orderType == 'phonecharges') {
                $scope.orderTypeTitle = '通讯费';
                $scope.img_icon = "img/home/pic_order_kd.png";
            } else if (orderType == 'mobile') {
                $scope.orderTypeTitle = '话费充值';
                $scope.img_icon = "img/myOrder/pic_order_hf.png";
            } else if (orderType == 'mobile_flow') {
                $scope.orderTypeTitle = '流量充值';
                $scope.img_icon = "img/myOrder/pic_order_ll.png";
            } else if (orderType == 'allyoucard') {
                $scope.orderTypeTitle = '油卡充值';
                $scope.img_icon = "img/myOrder/pic_order_yk.png";
            } else if (orderType == 'youcard') {
                $scope.orderTypeTitle = '中石油';
                $scope.img_icon = "img/myOrder/pic_order_yk.png";
            } else if (orderType == 'fulecard') {
                $scope.orderTypeTitle = '中石化';
                $scope.img_icon = "img/myOrder/pic_order_yk.png";
            }

            var dic = {
                'apiName': 'order.open',
                'order_type': 'lifeOrders',
                'function': 'getOrders',
                'order_tp': orderType,
                'page': '1',
                'size': '10'
            };

            function success_data(type) {
                $http(httpurl(dic))
                    .success(function (data) {
                        if (data.resultCode == '0000') {
                            if (data.result.count == '0') {
                                $scope.noDataBg = 'noDataBg';
                            } else {
                                $scope.noDataBg = 'bgFOF';
                                Array.prototype.push.apply($scope.data, data.result.data);
                                for (var i = 0; i < data.result.data.length; i++) {
                                    $scope.data[i + (dic.page - 2) * 10].createtime = getLocalTime(data.result.data[i].createtime);
                                    $scope.data[i + (dic.page - 2) * 10].total_amount = parseFloat(data.result.data[i].total_amount).toFixed(2);
                                    $scope.state[i + (dic.page - 2) * 10] = getState(data.result.data[i].pay_status, data.result.data[i].status, data.result.data[i].receive_status);
                                }
                            }

                        }
                        else {
                            $scope.popAlert(data.resultMessage)
                        }
                        if (type == 1) {
                            $scope.$broadcast('scroll.refreshComplete');
                        } else if (type == 2) {
                            if (data.result.data.length < 10) {
                                $scope.moredata = true;
                            }
                            $scope.$broadcast('scroll.infiniteScrollComplete');
                        }
                    })
                    .error(function (data, status, headers, config) {
                        $scope.popAlert("网络错误");
                    });
                dic.page = parseInt(dic.page) + 1;
            }

            $scope.doRefresh = function () {
                dic.page = 1;
                $scope.data = [];
                $scope.moredata = false;
                success_data(1);
            };
            $scope.loadMore = function () {
                success_data(2);
            }
            $scope.toOrderDetailSub = function (a, b, c, d) {
                sessionStorage.order_data = JSON.stringify([a, b, c, d]);
                location.href = "#/tab/orderDetailSub" + sessionStorage.Home;
                ;
            }

        })
        .controller('qiangshengOrderCtrl', function ($scope, $http) {
            $scope.moredata = false;
            $scope.state = [];
            $scope.data = [];
            var access_type = sessionStorage.access_type;
            if (access_type == '0005') {
                $scope.orderTypeTitle = '强生叫车';
                $scope.img_icon = "img/myOrder/pic_order_qsjc.png";
            } else if (access_type == '0004') {
                $scope.orderTypeTitle = '二维码';
                $scope.img_icon = "img/myOrder/pic_order_erweima.png";
            }

            var dic = {
                'apiName': 'order.open',
                'order_type': 'qrcodeOrders',
                'function': 'getOrders',
                'access_type': access_type,
                'page': '1',
                'size': '10'
            };

            function success_data(type) {

                $http(httpurl(dic))
                    .success(function (data) {
                        if (data.resultCode == '2005') {
                            var dicToken = {
                                'apiName': 'passport.token',
                                'token': sessionStorage.token
                            };
                            $http(httpurl(dicToken))
                                .success(function (data) {
                                    if (data.resultCode == '0000') {
                                        sessionStorage.token = data.result.token;
                                        dic.page = dic.page - 1;
                                        return success_data(type);
                                    } else {
                                        $scope.popAlert(data.resultMessage)
                                    }
                                })
                                .error(function (data, status, headers, config) {
                                    $scope.popAlert("网络错误！");
                                })
                        }
                        else if (data.resultCode == '0000') {
                            if (data.result.count == '0') {

                                $scope.noDataBg = 'noDataBg';
                            } else {
                                $scope.noDataBg = 'bgFOF';
                                Array.prototype.push.apply($scope.data, data.result.data);
                                for (var i = 0; i < data.result.data.length; i++) {
                                    $scope.data[i + (dic.page - 2) * 10].create_time = getLocalTime(data.result.data[i].create_time);
                                    $scope.data[i + (dic.page - 2) * 10].payed = parseFloat(data.result.data[i].payed).toFixed(2);
                                    $scope.state[i + (dic.page - 2) * 10] = getState(data.result.data[i].pay_status, data.result.data[i].status, data.result.data[i].receive_status);

                                }
                            }

                        }
                        else {
                            $scope.popAlert(data.resultMessage)
                        }
                        if (type == 1) {
                            $scope.$broadcast('scroll.refreshComplete');
                        } else if (type == 2) {
                            if (data.result.data.length < 10) {
                                $scope.moredata = true;
                            }
                            $scope.$broadcast('scroll.infiniteScrollComplete');
                        }
                    })
                    .error(function (data, status, headers, config) {
                        $scope.popAlert("网络错误！");
                    });
                dic.page = parseInt(dic.page) + 1;
            }

            $scope.doRefresh = function () {
                dic.page = 1;
                $scope.data = [];
                $scope.moredata = false;
                success_data(1);
            };
            $scope.loadMore = function () {
                success_data(2);
            }
            $scope.toOrderDetailSub = function (a, b, c, d) {
                sessionStorage.order_data = JSON.stringify([a, b, c, d]);
                location.href = "#/tab/orderDetailSub" + sessionStorage.Home;
            }

        })

        .controller('orderDetailCtrl', function ($scope) {
            $scope.toLink = function (link) {
                //sessionStorage.link = link + 'deviceType/0003';
                //location.href = '#/tab/personLink';
                location.href = link + 'deviceType/0003';
            }
            $scope.toUrl = function (x) {
                sessionStorage.orderType = x;
                location.href = '#/tab/waterOrder';
            }
            $scope.toUrl2 = function (x) {
                sessionStorage.access_type = x;
                location.href = "#/tab/qiangsheng";
            }
        })
        .controller('accountManageCtrl', function ($scope) {
            $scope.mobile = sessionStorage.usermobile;
            $scope.login_name = sessionStorage.useruname;
            if (sessionStorage.headimgurl == undefined) {
                $scope.headimgurl = 'img/person/pic-mrtx@3x.png';
            } else {
                $scope.headimgurl = sessionStorage.headimgurl;
            }
            $scope.email = sessionStorage.email;
            if ($scope.headimgurl == undefined) {
                $scope.headimgurl = 'img/person/pic-mrtx@3x.png';
            }
        })
        .controller('waterCtrl', function ($scope, $http) {
            if (sessionStorage.Home == 'Home') {
                $scope.indexPageName = '首页';
                $scope.indexPage = 'home';

            } else if (sessionStorage.Home == '') {
                $scope.indexPageName = '我的';
                $scope.indexPage = 'person';
            }
            var lifePayType = sessionStorage.lifePayType;
            if (lifePayType == '0001') {
                $scope.lifePay_icon = 'img/home/pic_sfy@3x.png';
                $scope.typeName = '水费';
                $scope.lifePayTypeName = 'water';
            } else if (lifePayType == '0002') {
                $scope.lifePay_icon = 'img/home/pic_dfy@3x.png';
                $scope.typeName = '电费';
                $scope.lifePayTypeName = 'electricity';
            } else if (lifePayType == '0003') {
                $scope.lifePay_icon = 'img/home/pic_mqfy@3x.png';
                $scope.typeName = '煤气费';
                $scope.lifePayTypeName = 'gas';
            } else if (lifePayType == '0004') {
                $scope.lifePay_icon = 'img/home/pic_kd@3x.png';
                $scope.typeName = '通讯费';
                $scope.lifePayTypeName = 'phonecharges';
            }
            $scope.payComname = "";
            $scope.waterSelectBox = false;
            $scope.waterSelectBody = false;
            $scope.paymoney = false;
            $scope.scanCode = false;
            $scope.historyBox = false;
            $scope.eleHistory = false;
            $scope.eleQueryImg = false;
            $scope.deleteBtn = [];
            $scope.nextBox = true;
            $scope.provinceBox = true;
            $scope.cityBox = false;
            $scope.nextBox = false;
            $scope.payTypeShow = false;
            var agencyNoA = '', payComnameA = '', cityNameA = '', typeId = '', typeIndex;

            $scope.toUrl = function (x) {
                sessionStorage.orderType = x;
                location.href = '#/tab/waterOrder' + sessionStorage.Home;
                ;

            }
            $scope.saveHistory = function (x) {
                $scope.payaccount = x;
                $scope.historyBox = false;
            }
            $scope.waterSelectBodyClick = function () {
                $scope.waterSelectBox = false;
                $scope.waterSelectBody = false;
            }

            $scope.queryNoMoney = function (payaccount) {
                if (payaccount == undefined) {
                    $scope.popAlert('请输入' + $scope.payType[typeIndex].typeName + '!');
                } else {
                    var dic = {
                        'apiName': 'life.select',
                        'money': '0',
                        'companyId': agencyNoA,
                        'payType': typeId,
                        'payaccount': payaccount,
                        'type': lifePayType
                    };
                    $scope.loadingBox = true;
                    $http(httpurl(dic))
                        .success(function (data) {
                            $scope.loadingBox = false;
                            if (data.resultCode == '0000') {
                                $scope.eleHistory = true;
                                $scope.nowTo = data.result;
                                $scope.nextBox = false;
                            } else {
                                $scope.popAlert(data.resultMessage);
                            }
                        })
                        .error(function (data, status, headers, config) {
                            $scope.popAlert('网络错误！');
                        })
                }

            }
            $scope.createOrder = function (payaccountA, billDate, uniqueNo, sand_amount) {
                var dic = {
                    'apiName': 'life.create',
                    'money': sand_amount,
                    'companyId': agencyNoA,
                    'payType': typeId,
                    'payaccount': payaccountA,
                    'billDate': billDate,
                    'company_name': payComnameA,
                    'region_name': cityNameA,
                    'unique_no': uniqueNo,
                    'type': lifePayType
                };
                $scope.loadingBox = true;
                $http(httpurl(dic))
                    .success(function (data) {
                        $scope.loadingBox = false;
                        if (data.resultCode == '0000') {
                            wechatpay(data.result.id)
                        } else {
                            $scope.popAlert(data.resultMessage)
                        }
                    })
                    .error(function (data, status, headers, config) {
                        $scope.popAlert('网络错误！');
                    })


            }
            $scope.historyFun = function () {
                $scope.historyBox = !$scope.historyBox;
                if ($scope.historyBox == true) {
                    var dic = {
                        'apiName': 'life.history',
                        'companyId': agencyNoA,
                        'payType': typeId
                    };
                    $scope.loadingBox = true;
                    $http(httpurl(dic))
                        .success(function (data) {
                            $scope.loadingBox = false;
                            $scope.history = data.result;
                            if (data.result.length != undefined) {
                                for (var i in data.result) {
                                    $scope.deleteBtn[i] = "删除";
                                }
                            } else {
                                $scope.deleteBtn[0] = "";
                            }


                        })
                        .error(function (data, status, headers, config) {
                            $scope.popAlert('网络错误！');
                        })
                }

            }
            $scope.historyDelete = function (dele_id, index) {
                var dic = {
                    'apiName': 'life.delefulehistory',
                    'companyId': agencyNoA,
                    'payType': typeId,
                    'dele_id': dele_id,
                    'type': 0003,
                    'companyId': agencyNoA,
                    'payType': typeId
                };
                $scope.loadingBox = true;
                $http(httpurl(dic))
                    .success(function (data) {
                        $scope.loadingBox = false;
                        if (data.resultCode = '0000') {
                            $scope.historyBox = false;
                            if (index == 'all') {
                                $scope.deleteBtn = [];
                                $scope.popAlert(data.result.msg);
                            } else {
                                $scope.popAlert(data.result.msg);
                            }
                        } else {
                            $scope.popAlert(data.resultMessage)
                        }


                    })
                    .error(function (data, status, headers, config) {
                        $scope.popAlert('网络错误！');
                    })
            }
            $scope.waterSelectBodyClick = function () {
                $scope.waterSelectBox = false;
                $scope.waterSelectBody = false;
            }
            $scope.openPopover = function () {
                $scope.provinceBox = true;
                $scope.cityBox = false;
                $scope.companyBox = false;
                $scope.waterSelectBox = true;
                $scope.waterSelectBody = true;
                $scope.loadingBox = true;
                var dic = {
                    'apiName': 'life.kind',
                    'type': lifePayType
                };
                $http(httpurl(dic))
                    .success(function (data) {
                        $scope.billBaseData = data.result.billBaseData;
                        $scope.loadingBox = false;

                    })
                    .error(function (data, status, headers, config) {
                        $scope.popAlert("error");
                    })

            }
            $scope.toCity = function (provinceName) {
                for (var i = 0; i < $scope.billBaseData.length; i++) {
                    if ($scope.billBaseData[i].provinceName == provinceName) {
                        $scope.cityList = $scope.billBaseData[i].cityList;
                        break;
                    }
                }
                $scope.provinceBox = false;
                $scope.cityBox = true
                $scope.companyBox = false;
                ;
            }
            $scope.toCompany = function (cityName) {
                for (var i = 0; i < $scope.billBaseData.length; i++) {
                    for (var j = 0; j < $scope.billBaseData[i].cityList.length; j++) {
                        if ($scope.billBaseData[i].cityList[j].cityName == cityName) {
                            $scope.payCommInfos = $scope.billBaseData[i].cityList[j].payCommInfos;
                            cityNameA = cityName;
                            break;
                        }
                    }

                }
                $scope.provinceBox = false;
                $scope.cityBox = false;
                $scope.companyBox = true;
                $scope.nextBox = false;

            }
            $scope.companyClik = function (payComname, agencyNo, payType) {
                $scope.waterSelectBody = false;
                $scope.waterSelectBox = false;
                $scope.payTypeShow = true;
                $scope.payComname = cutString(payComname, 22);
                agencyNoA = agencyNo;
                payComnameA = payComname;
                $scope.payType = payType;
                typeId = payType[0].typeId;
                typeIndex = 0;
                $scope.payTypeBtn = ['btnClearRed', 'btnClear'];
                $scope.nextBox = true;
                $scope.eleHistory = false;
                $scope.payTypetypeName=$scope.payType[typeIndex].typeName;

            }

            $scope.surePayType = function (typeIddd, index) {
                for (var i = 0; i < $scope.payType.length; i++) {
                    $scope.payTypeBtn[i] = 'btnClear';
                }
                $scope.payTypeBtn[index] = 'btnClearRed';
                typeId = typeIddd;
                typeIndex = index;
                $scope.payTypetypeName=$scope.payType[typeIndex].typeName;
                $scope.nextBox = true;
            }


        })
        .controller('toBePayCtrl', function ($scope, $http) {
            $scope.moredata = false;
            $scope.state = [];
            $scope.data = [];
            $scope.order_Type = [];
            var dic = {
                'apiName': 'order.open',
                'function': 'getOrders',
                'page': '1',
                'size': '10'
            };
            var orderType = sessionStorage.orderType;
            if (orderType == 'allOrders') {
                $scope.orderTypeTitle = '待支付订单';
                dic.order_type = orderType;
                dic.type = 'all'
            } else if (orderType == 'cpsOrders') {
                $scope.orderTypeTitle = '特享用户订单';
                dic.order_type = orderType;
                dic.status = 'all'
            }
            function success_data(type) {
                $http(httpurl(dic))
                    .success(function (data) {
                        if (data.resultCode == '0000') {
                            Array.prototype.push.apply($scope.data, data.result.data);
                            for (var i = 0; i < data.result.data.length; i++) {
                                var item = i + (dic.page - 2) * 10;
                                var orderType = data.result.data[i].order_type;
                                if (orderType == 'water') {
                                    $scope.order_Type[item] = '水费';
                                    data.result.data[i].logo = "img/myOrder/pic_order_shui.png";
                                } else if (orderType == 'electricity') {
                                    $scope.order_Type[item] = '电费';
                                    data.result.data[i].logo = "img/myOrder/pic_order_dian.png";
                                } else if (orderType == 'gas') {
                                    $scope.order_Type[item] = '煤气费';
                                    data.result.data[i].logo = "img/myOrder/pic_order_trq.png";
                                } else if (orderType == 'phonecharges') {
                                    $scope.order_Type[item] = '通讯费';
                                    data.result.data[i].logo = "img/myOrder/pic_order_kd.png";
                                } else if (orderType == 'mobile') {
                                    $scope.order_Type[item] = '话费充值';
                                    data.result.data[i].logo = "img/myOrder/pic_order_s.png";
                                } else if (orderType == 'mobile_flow') {
                                    $scope.order_Type[item] = '流量充值';
                                    data.result.data[i].logo = "img/myOrder/pic_order_ll.png";
                                } else if (orderType == 'youcard' || orderType == 'fulecard') {
                                    $scope.order_Type[item] = '油卡充值';
                                    data.result.data[i].logo = "img/myOrder/pic_order_yk.png";
                                } else if (orderType == 'ecoupon') {
                                    $scope.order_Type[item] = '优惠券';
                                    data.result.data[i].logo = "img/myOrder/pic_order_quan.png";
                                } else {
                                    if (data.result.data[i].short_name == undefined) {
                                        $scope.order_Type[item] = '商品订单';
                                    } else {
                                        $scope.order_Type[item] = cutString(data.result.data[i].short_name, 16);
                                    }

                                    if ($scope.data[item].logo == undefined || $scope.data[item].logo == '' || $scope.data[item].logo == "http://test.sandlife.com.cn/") {
                                        $scope.data[item].logo = 'img/myOrder/pic_shsd@3x.png';

                                    }
                                }
                                $scope.data[item].createtime = getLocalTime(data.result.data[i].createtime);
                                $scope.data[item].total_amount = parseFloat(data.result.data[i].total_amount).toFixed(2);
                                $scope.state[item] = getState(data.result.data[i].pay_status, data.result.data[i].status, data.result.data[i].receive_status);
                            }
                            if ($scope.data.length == 0) {

                                $scope.noDataBg = 'noDataBg';
                            } else {
                                $scope.noDataBg = 'bgFOF';
                            }
                        } else {
                            $scope.popAlert(data.resultMessage)
                        }
                        if (type == 1) {
                            $scope.$broadcast('scroll.refreshComplete');

                        } else if (type == 2) {

                            if (data.result.data.length < 10 || data.result.data.length == undefined) {
                                $scope.moredata = true;

                            }

                            $scope.$broadcast('scroll.infiniteScrollComplete');
                        }
                    })
                    .error(function (data, status, headers, config) {
                        $scope.popAlert("网络错误！");
                    });
                dic.page = parseInt(dic.page) + 1;
            }

            $scope.doRefresh = function () {
                $scope.dataStateShow = false;
                dic.page = 1;
                $scope.data = [];
                $scope.moredata = false;
                success_data(1);
            };
            $scope.loadMore = function () {
                success_data(2);
            }
            $scope.toOrderDetailSub = function (a, b, c, d) {
                sessionStorage.order_data = JSON.stringify([a, b, c, d]);
                location.href = "#/tab/orderDetailSub";
            }


        })
        .controller('orderDetailSubCtrl', function ($scope, $http) {
            if (sessionStorage.Home == 'Home') {
                $scope.indexPageName = '首页';
                $scope.indexPage = 'home';

            } else if (sessionStorage.Home == '') {
                $scope.indexPageName = '我的';
                $scope.indexPage = 'person';
            }
            $scope.order_id = JSON.parse(sessionStorage.order_data)[0];
            $scope.createtime = JSON.parse(sessionStorage.order_data)[1].replace("<br/>", "");
            $scope.total_amount = JSON.parse(sessionStorage.order_data)[2];
            $scope.state = JSON.parse(sessionStorage.order_data)[3].replace("<br/>", "");
            $scope.payBoxShowEnjoy = false;
            $scope.sureBtn = 'redBtn marginR50';
            $scope.cancelBtn = true;
            var orderType = sessionStorage.orderType;
            if ($scope.state == '等待付款' || $scope.state == '部分付款') {
                $scope.payBoxShow = true;
                if (orderType == 'cpsOrders') {
                    $scope.sureBtn = 'btnSureT10';
                    $scope.cancelBtn = false;
                } else {
                    $scope.sureBtn = 'redBtn marginR50';
                    $scope.cancelBtn = true;
                }

            } else {
                $scope.payBoxShow = false;
            }

            $scope.toPay = function (id) {
                wechatpay(id);
            }
            $scope.toCancel = function (id) {
                var dic = {
                    'apiName': 'orders.cancel',
                    'order_id': id
                };
                $scope.loadingBox = true;
                $http(httpurl(dic))
                    .success(function (data) {
                        $scope.loadingBox = false;
                        if (data.resultCode == '0000') {
                            $scope.popAlert('订单取消成功！')
                        } else {
                            $scope.popAlert(data.resultMessage);
                        }

                    })
                    .error(function (data, status, headers, config) {
                        $scope.popAlert(status);
                    })
            }
        })
        .controller('currencyCtrl', function ($scope, $http) {
            function currencyFun() {
                var dic = {
                    'apiName': 'passport.sandaccount'
                };
                $scope.loadingBox = true;
                $http(httpurl(dic))
                    .success(function (data) {
                        $scope.loadingBox = false;
                        if (data.result.main_account == undefined) {
                            $scope.main_account_accBal = 0.00;
                        } else {
                            $scope.main_account_accBal = parseInt(data.result.main_account.accBal) / 100;
                        }

                    })
                    .error(function (data, status) {
                        $scope.popAlert(status);
                    })
            }

            currencyFun();

            $scope.toDetail = function (x) {
                sessionStorage.accountdetailbusiness = x;
                location.href = "#/tab/accountDetail"
            }
        })
        .controller('sandBeToCtrl', function ($scope, $http) {
            $scope.sandBeCharge = function (couponCode) {
                if (couponCode == undefined) {
                    $scope.popAlert('请输入充值码！')
                } else {
                    var dic = {
                        'apiName': 'coin.recharge',
                        'couponcode': couponCode,
                        'type': '10000003'
                    };
                    $scope.loadingBox = true;
                    $http(httpurl(dic))
                        .success(function (data) {
                            $scope.loadingBox = false;
                            $scope.popAlert(data.resultMessage);
                        })
                        .error(function (data, status, headers, config) {
                            $scope.popAlert('网络错误！')
                        })

                }
            }
        })
        .controller('sandCoinCtrl', function ($scope, $http) {
            function sandCoinFun() {
                var dic = {
                    'apiName': 'passport.sandaccount',
                };
                $scope.loadingBox = true;
                $http(httpurl(dic))
                    .success(function (data) {


                        if (data.result.sandcoin_account == undefined) {
                            $scope.sandcoin_accountaccBal = 0.00;
                            $scope.sandcoin_accHoldBal = 0;
                        } else {
                            $scope.sandcoin_accountaccBal = parseInt(data.result.sandcoin_account.accBal) / 100;
                            $scope.sandcoin_accHoldBal = parseInt(data.result.sandcoin_account.accHoldBal) / 100;
                        }


                        $scope.loadingBox = false;
                    })
                    .error(function (data, status, headers, config) {
                        $scope.popAlert('网络错误！')
                    });
            }

            sandCoinFun();

            $scope.toDetail = function (x) {
                sessionStorage.accountdetailbusiness = x;
                location.href = "#/tab/accountDetail"
            }
        })
        .controller('superCtrl', function ($scope, $http) {
            $scope.loadingBox = true;
            function superFun() {
                var dic = {
                    'apiName': 'passport.sandaccount'
                };
                $http(httpurl(dic))
                    .success(function (data) {
                        if (data.result.sandcoin_account != undefined) {
                            if (data.result.proper_account.accBal == undefined) {
                                $scope.proper_accountaccBal = 0.00;
                            } else {
                                $scope.proper_accountaccBal = parseInt(data.result.proper_account.accBal) / 100;
                            }


                        } else {
                            $scope.proper_accountaccBal = 0;
                        }
                        $scope.loadingBox = false;

                    })
                    .error(function (data, status, headers, config) {
                        $scope.popAlert('网络错误！')
                    });
            }

            superFun();
            $scope.toDetail = function (x) {
                sessionStorage.accountdetailbusiness = x;
                location.href = "#/tab/accountDetail"
            }

            $scope.toLink = function (link) {
                location.href = link + 'deviceType/0003';

            }


        })
        .controller('walletCtrl', function ($scope) {
            $scope.toLink = function (link) {
                location.href = link + 'deviceType/0003';
            }
            $scope.toUrl = function (x) {
                location.href = '#/tab/' + x + 'Person';
            }
        })
        .controller('accountDetailCtrl', function ($scope, $http) {
            var accountdetailbusiness = sessionStorage.accountdetailbusiness;
            $scope.moredata = false;
            $scope.datalist = [];
            var dic = {
                'apiName': 'passport.accountdetail',
                'page': '1',
                'pageLine': '10',
                'business': accountdetailbusiness
            };

            function success_data(type) {

                $http(httpurl(dic))
                    .success(function (data) {

                        if (data.resultCode == '0000') {
                            if (data.result.datalist.length == '0') {
                                $scope.noDataBg = 'noDataBg';
                            } else {
                                $scope.noDataBg = 'bgFOF';
                                Array.prototype.push.apply($scope.datalist, data.result.datalist);
                                for (var i = 0; i < data.result.datalist.length; i++) {
                                    data.result.datalist[i].transAmt = parseFloat(data.result.datalist[i].transAmt) / 100;
                                    var x = data.result.datalist[i].transDate, y = data.result.datalist[i].transTime;
                                    x = insert_flg(x, '.', 4);
                                    x = insert_flg(x, '.', 7);
                                    y = insert_flg(y, ':', 2);
                                    y = insert_flg(y, ':', 5);
                                    data.result.datalist[i].transDate = x;
                                    data.result.datalist[i].transTime = y;
                                }


                            }
                        } else {
                            $scope.popAlert(data.resultMessage);
                        }
                        if (type == 1) {
                            $scope.$broadcast('scroll.refreshComplete');
                        } else if (type == 2) {
                            if (data.result.datalist.length < 10) {
                                $scope.moredata = true;
                            }
                            $scope.$broadcast('scroll.infiniteScrollComplete');
                        }

                    })
                    .error(function (data, status, headers, config) {
                        $scope.popAlert("error");
                    });

                dic.page = parseInt(dic.page) + 1;
            }

            $scope.doRefresh = function () {
                dic.page = 1;
                $scope.datalist = [];
                $scope.moredata = false;
                success_data(1);
            };
            $scope.loadMore = function () {
                success_data(2);

            }
        })
        .controller('couponCtrl', function ($scope, $http) {

            $scope.moredata = false;
            $scope.state = [];
            $scope.item_list = [];
            $scope.toLink = function (link) {
                sessionStorage.link = link;
                location.href = '#/tab/personLink';

            }

            var dic = {
                'apiName': 'ecoupon.list',
                'page_no': '1',
                'page_size': '10'
            };

            function success_data(type) {

                $http(httpurl(dic))
                    .success(function (data) {

                        if (data.resultCode == '0000') {
                            if (data.result.ecoupon_num == '0') {
                                $scope.noDataBg = 'noDataBg';

                            } else {
                                $scope.noDataBg = 'bgFOF';
                                Array.prototype.push.apply($scope.item_list, data.result.item_list);
                                for (var i = 0; i < data.result.item_list.length; i++) {
                                    $scope.item_list[i + (dic.page_no - 2) * 10].dma = parseFloat(data.result.item_list[i].dma).toFixed(2);
                                    $scope.item_list[i + (dic.page_no - 2) * 10].start_time = getLocalTimeDate(data.result.item_list[i].start_time);
                                    $scope.item_list[i + (dic.page_no - 2) * 10].end_time = getLocalTimeDate(data.result.item_list[i].end_time);
                                    if (data.result.item_list[i].ecoupon_status == 0) {
                                        $scope.item_list[i + (dic.page_no - 2) * 10].ecoupon_status = '可以使用'
                                    } else if (data.result.item_list[i].ecoupon_status == 1) {
                                        $scope.item_list[i + (dic.page_no - 2) * 10].ecoupon_status = '已经使用'
                                    }
                                    if (data.result.item_list[i].ecoupon_status == 2) {
                                        $scope.item_list[i + (dic.page_no - 2) * 10].ecoupon_status = '已经作废'
                                    }
                                }
                            }

                        }
                        else {
                            $scope.popAlert(data.resultMessage)
                        }
                        if (type == 1) {
                            $scope.$broadcast('scroll.refreshComplete');
                        } else if (type == 2) {
                            if (data.result.item_list.length < 10) {
                                $scope.moredata = true;
                            }
                            $scope.$broadcast('scroll.infiniteScrollComplete');
                        }
                    })
                    .error(function (data, status, headers, config) {
                        $scope.popAlert(status)
                    });
                dic.page_no = parseInt(dic.page_no) + 1;
            }


            $scope.doRefresh = function () {
                dic.page_no = 1;
                $scope.item_list = [];
                $scope.moredata = false;
                success_data(1);
            };
            $scope.loadMore = function () {
                success_data(2);
            }
            $scope.toConponDetail = function (index) {
                sessionStorage.coupon_item_list = JSON.stringify($scope.item_list[index]);
                location.href = '#/tab/couponDetail';
            }
        })
        .controller('couponDetailCtrl', function ($scope, $http) {
            var item_list = JSON.parse(sessionStorage.coupon_item_list);
            $scope.inputTel = false;
            $scope.cashcoupon_image_url = item_list.cashcoupon_image_url;
            $scope.name = item_list.name;
            $scope.start_time = item_list.start_time;
            $scope.dma = item_list.dma;
            $scope.ecoupon_status = item_list.ecoupon_status;
            $scope.end_time = item_list.end_time;
            $scope.coupon_bn = item_list.coupon_bn;
            $scope.mobile = item_list.mobile;
            function couponDetailFun() {
                var dic = {
                    'apiName': 'ecouponCode.show',

                    'item_id': item_list.item_id
                };
                $scope.loadingBox = true;
                $http(httpurl(dic))
                    .success(function (data) {
                        $scope.loadingBox = false;
                        if (data.resultCode == '0000') {
                            $scope.msgCode = data.result.outputBeanList.msgCode;
                            $scope.urlHtml = data.result.outputBeanList.barcode;
                        }
                        else {
                            $scope.popAlert(data.resultMessage)
                        }
                    })
                    .error(function (data, status, headers, config) {
                        $scope.popAlert(status)
                    });
            }

            couponDetailFun();
            $scope.toSend = function () {
                if (item_list.ecoupon_status == '可以使用') {
                    $scope.inputTel = true;
                    $scope.mobile = item_list.mobile;
                }

            }
            $scope.toSure = function (mobile) {
                if (myreg.test(mobile)) {
                    var dic = {
                        'apiName': 'ecouponCode.send',

                        'item_id': item_list.item_id,
                        'mobile': mobile
                    };
                    $scope.loadingBox = true;
                    $http(httpurl(dic))
                        .success(function (data) {
                            $scope.loadingBox = false;
                            if (data.resultCode == '0000') {
                                $scope.popAlert(data.result.errMsg);
                                $scope.inputTel = false;
                            }
                            else {
                                $scope.popAlert(data.resultMessage)
                            }

                        })
                        .error(function (data, status, headers, config) {
                            $scope.popAlert(status)
                        });
                } else {
                    $scope.popAlert("请输入有效的手机号!");
                }
            }
            $scope.toCancel = function () {
                $scope.inputTel = false;
            }
        })
        .controller('phoneChargeCtrl', function ($scope, $http, $ionicHistory) {
            $scope.toggleContent1 = true;
            $scope.toggleContent2 = false;
            $scope.toggle1 = 'colorRed';
            $scope.toggle2 = '';
            $scope.libottom1 = true;
            $scope.libottom2 = false;
            $scope.oilBtn = [];
            $scope.flowBtn = [];
            $scope.phoneCityeOperator = "运营商";
            $scope.flowCityeOperator = "运营商";
            $scope.price = 0.00;
            $scope.flowprice = 0.00;
            $scope.popShow = false;
            $scope.popContentShow = false;
            $scope.chargeBtn = 'grayBtn floatR';
            $scope.chargeMoney = 'chargeMoney_1';
            $scope.flowchargeBtn = 'grayBtn floatR';
            $scope.flowchargeMoney = 'chargeMoney_1';
            $scope.type = 'mobile';
            var flowAmtLength = 0;
            var product_id = 0;
            var phoneBtnClick = false, flowBtnClick = false;
            $scope.mobile = sessionStorage.usermobile;
            if (sessionStorage.Home == 'Home') {
                $scope.indexPageName = '首页';
                $scope.indexPage = 'home';

            } else if (sessionStorage.Home == '') {
                $scope.indexPageName = '我的';
                $scope.indexPage = 'person';
            }
            $scope.oilBtnClick = function (x, y, mobile) {
                if (myreg.test(mobile)) {
                    for (var i = 0; i < $scope.oilBtn.length; i++) {
                        $scope.oilBtn[i] = 'oilBtn';
                    }
                    $scope.oilBtn[x] = 'oilBtnRed';
                    $scope.price = y;
                    phoneBtnClick = true;
                    $scope.chargeBtn = 'redBtn floatR';
                    $scope.chargeMoney = 'chargeMoney_2';
                }
            }
            $scope.flowBtnClick = function (mobile, x, y, z) {
                if (myreg.test(mobile)) {
                    for (var i = 0; i < $scope.flowBtn.length; i++) {
                        $scope.flowBtn[i] = 'oilBtn';
                    }
                    $scope.flowBtn[x] = 'oilBtnRed';
                    $scope.flowprice = y;
                    product_id = z;
                    flowBtnClick = true;
                    $scope.flowchargeBtn = 'redBtn floatR';
                    $scope.flowchargeMoney = 'chargeMoney_2';
                }
            }
            $scope.phoneKeyup = function (mobile) {
                if (myreg.test(mobile)) {
                    var dic = {
                        'apiName': 'phone.select',
                        'phoneNumber': mobile
                    };
                    $scope.loadingBox = true;
                    $http(httpurl(dic))
                        .success(function (data) {
                            $scope.loadingBox = false;
                            if (data.resultCode == '0000') {
                                $scope.phoneCityeOperator = data.result.city + ' ' + data.result.operators;
                                $scope.phoneSale = data.result.sale;
                                for (var i = 0; i < getJsonLength($scope.phoneSale); i++) {
                                    $scope.oilBtn[i] = 'oilBtn';
                                }
                            } else {
                                $scope.popAlert(data.resultMessage);
                            }
                        })
                        .error(function (data, status, headers, config) {
                            $scope.popAlert(data)

                        })

                } else if (mobile.length == 10) {
                    for (var i = 0; i < getJsonLength($scope.phoneSale); i++) {
                        $scope.oilBtn[i] = 'oilBtnGray';
                    }
                    $scope.phoneCityeOperator = "运营商";
                    $scope.price = 0;
                    $scope.chargeBtn = 'grayBtn floatR';
                    $scope.chargeMoney = 'chargeMoney_1';
                    phoneBtnClick = false;
                } else if (mobile.length == 11) {
                    $scope.popShow = true;
                    $scope.popContentShow = true;
                    $scope.popContent = "请输入有效的手机号!";
                    $scope.phoneCityeOperator = "运营商";
                    $scope.price = 0;
                    $scope.chargeBtn = 'grayBtn floatR';
                    $scope.chargeMoney = 'chargeMoney_1';
                    phoneBtnClick = false;
                }
            }


            if ($scope.mobile == undefined || $scope.mobile == '') {
                $scope.mobile = '';
                $scope.phoneSale = {
                    "30": "30",
                    "50": "50",
                    "100": "100",
                    "200": "200",
                    "300": "300",
                    "500": "500"
                }
                $scope.result = [
                    {amt: "3.00", flow_num: "10M"},
                    {amt: "5.00", flow_num: "30M"},
                    {amt: "10.00", flow_num: "70M"},
                    {amt: "20.00", flow_num: "150M"},
                    {amt: "30.00", flow_num: "500M"},
                    {amt: "50.00", flow_num: "1024M"}
                ]
                for (var i = 0; i < 6; i++) {
                    $scope.oilBtn[i] = $scope.flowBtn[i] = 'oilBtnGray';
                }
            } else {
                $scope.flowmobile = $scope.mobile;
                $scope.phoneKeyup($scope.mobile);

            }

            $scope.toggle = function (x) {
                if (x == 1) {
                    $scope.toggleContent1 = true;
                    $scope.toggleContent2 = false;
                    $scope.libottom1 = true;
                    $scope.libottom2 = false;
                    $scope.toggle1 = 'colorRed';
                    $scope.toggle2 = '';
                    $scope.type = 'mobile';
                } else {
                    $scope.toggleContent1 = false;
                    $scope.toggleContent2 = true;
                    $scope.libottom1 = false;
                    $scope.libottom2 = true;
                    $scope.toggle1 = '';
                    $scope.toggle2 = 'colorRed';
                    $scope.type = 'mobile_flow';
                    $scope.flowKeyup = function (mobile) {
                        if (myreg.test(mobile)) {
                            var dic = {
                                'apiName': 'flow.select',
                                'phoneNumber': mobile
                            };
                            $scope.loadingBox = true;
                            $http(httpurl(dic))
                                .success(function (data) {
                                    $scope.loadingBox = false;
                                    if (data.resultCode == '0000') {
                                        $scope.result = data.result.product;
                                        flowAmtLength = data.result.product.length;
                                        $scope.flowCityeOperator = data.result.cityoperators[0] + ' ' + data.result.cityoperators[1];
                                        for (var i = 0; i < data.result.product.length; i++) {
                                            $scope.result[i].amt = (parseFloat($scope.result[i].amt) / 100).toFixed(2);
                                            $scope.flowBtn[i] = 'oilBtn';

                                        }
                                    } else {
                                        $scope.popAlert(data.resultMessage);
                                    }


                                })
                                .error(function (data, status, headers, config) {
                                    $scope.popAlert(data);
                                })

                        } else if (mobile.length == 10) {
                            for (var i = 0; i < flowAmtLength; i++) {
                                $scope.flowBtn[i] = 'oilBtnGray';
                                $scope.flowCityeOperator = "运营商";
                                $scope.flowprice = 0;
                                $scope.flowchargeBtn = 'grayBtn floatR';
                                $scope.flowchargeMoney = 'chargeMoney_1';
                                flowBtnClick = false;
                            }

                        } else if (mobile.length == 11) {
                            $scope.popShow = true;
                            $scope.popContentShow = true;
                            $scope.popContent = "请输入有效的手机号!";
                            $scope.flowCityeOperator = "运营商";
                            $scope.flowprice = 0;
                            $scope.flowchargeBtn = 'grayBtn floatR';
                            $scope.flowchargeMoney = 'chargeMoney_1';
                            flowBtnClick = false;
                        }

                    }

                    $scope.flowKeyup($scope.flowmobile);
                }

            }
            $scope.toUrl = function (x) {
                sessionStorage.orderType = x;
                location.href = '#/tab/waterOrder' + sessionStorage.Home;

            }
            $scope.popHide = function () {
                $scope.popShow = false;

            }
            $scope.billCharge = function (mobile) {
                if (myreg.test(mobile) && phoneBtnClick) {
                    var dic = {
                        'apiName': 'phone.recharge',
                        'phoneNumber': mobile,

                        'amount': $scope.price
                    };
                    $scope.loadingBox = true;
                    $http(httpurl(dic))
                        .success(function (data) {
                            $scope.loadingBox = false;
                            if (data.resultCode == '0000') {
                                wechatpay(data.result.id);
                            } else {
                                $scope.popAlert(data.resultMessage);
                            }

                        })
                        .error(function (data, status, headers, config) {
                            $scope.popAlert(data);
                        })
                }
            }
            $scope.flowCharge = function (mobile) {
                if (myreg.test(mobile) && flowBtnClick) {
                    var dic = {
                        'apiName': 'flow.recharge',
                        'phoneNumber': mobile,

                        'flow_amt': $scope.flowprice,
                        'product_id': product_id
                    };
                    $scope.loadingBox = true;
                    $http(httpurl(dic))
                        .success(function (data) {
                            $scope.loadingBox = false;

                            if (data.resultCode == '0000') {
                                wechatpay(data.result.id)
                            } else {
                                $scope.popAlert(data.resultMessage);
                            }

                        })
                        .error(function (data, status, headers, config) {
                            $scope.popAlert(data);
                        })

                }

            }
        })
        .controller('oilChargeCtrl', function ($scope, $http) {
            $scope.oilHistoryShow = false;
            $scope.oilBtn = [];
            $scope.toggleContent1 = false;
            $scope.toggleContent2 = true;
            $scope.libottom1 = true;
            $scope.libottom2 = false;
            $scope.toggle1 = 'colorRed';
            $scope.toggle2 = '';
            $scope.oilTwoBoxShow = false;
            $scope.chargeMoneyShow = true;
            $scope.cardType = 'fulecard';
            $scope.toPayBtn1 = 'btnT10';
            $scope.toPayBtn2 = 'btnT10';
            $scope.inputDate = {cardNum1: '', name: '', mobile: sessionStorage.usermobile, chargeMoney1: ''}
            $scope.inputDate2 = {cardNum2: '', name: '', mobile: sessionStorage.usermobile, chargeMoney2: ''}
            var oilType = 2;//1为中石油，2为中石化
            var chargeMoney;
            var chargeType = '50_10000';
            if (sessionStorage.Home == 'Home') {
                $scope.indexPageName = '首页';
                $scope.indexPage = 'home';

            } else if (sessionStorage.Home == '') {
                $scope.indexPageName = '我的';
                $scope.indexPage = 'person';
            }
            $scope.toggle = function (x) {
                oilType = x;
                if (x == 1) {
                    $scope.libottom1 = true;
                    $scope.libottom2 = false;
                    $scope.toggle1 = 'colorRed';
                    $scope.toggle2 = '';
                    $scope.toggleContent1 = true;
                    $scope.toggleContent2 = false;
                    $scope.cardType = 'youcard';
                    $scope.oilHistoryShow = false;
                } else if (x == 2) {
                    $scope.libottom1 = false;
                    $scope.libottom2 = true;
                    $scope.toggle1 = '';
                    $scope.toggle2 = 'colorRed';
                    $scope.toggleContent1 = false;
                    $scope.toggleContent2 = true;
                    $scope.cardType = 'fulecard';
                    $scope.oilHistoryShow = false;
                }
            }


            $scope.toUrl = function (x) {
                sessionStorage.orderType = x;
                location.href = '#/tab/waterOrder' + sessionStorage.Home;

            }

            for (var i = 0; i < 3; i++) {
                $scope.oilBtn[i] = 'oilBtn';
            }
            $scope.oilBtnClick = function (x, cardNum2, name, mobile, y) {
                for (var i = 0; i < 3; i++) {
                    $scope.oilBtn[i] = 'oilBtn';
                }
                $scope.oilBtn[x] = 'oilBtnRed';
                chargeMoney = y;
                chargeType = '500';
                if (cardNum2.length == 19 && name != '' && myreg.test(mobile) && y != undefined) {
                    $scope.toPayBtn2 = 'btnSureT10';
                } else {
                    $scope.toPayBtn2 = 'btnT10';
                }

            }
            $scope.oilHistory = function (type) {
                $scope.oilHistoryShow = !$scope.oilHistoryShow;
                var dic = {
                    'apiName': 'life.fulehistory',

                    'type': type
                };
                if ($scope.oilHistoryShow == true) {
                    $scope.loadingBox = true;
                    $http(httpurl(dic))
                        .success(function (data) {
                            $scope.loadingBox = false;
                            if (data.resultCode == '0000') {
                                $scope.cardHistory = [];
                                if (data.result.msg == "您没有卡号记录") {
                                    $scope.oilHistoryShow = false;
                                    $scope.popAlert("您没有卡号记录!");
                                } else {
                                    for (var i = 0; i < data.result.length; i++) {
                                        $scope.cardHistory[i] = data.result[i].cardno;
                                    }
                                }

                                $scope.useHistory = function (index) {

                                    if (oilType == 1) {
                                        $scope.inputDate.cardNum1 = data.result[index].cardno;
                                        $scope.inputDate.name = data.result[index].name;
                                        $scope.inputDate.mobile = data.result[index].mobile;
                                        $scope.chargeKeyup1($scope.inputDate.cardNum1, $scope.inputDate.name, $scope.inputDate.mobile, $scope.inputDate.chargeMoney1);

                                    } else {
                                        $scope.inputDate2.name = data.result[index].name;
                                        $scope.inputDate2.mobile = data.result[index].mobile;
                                        $scope.inputDate2.cardNum2 = data.result[index].cardno;
                                        $scope.chargeKeyup2($scope.inputDate2.cardNum2, $scope.inputDate2.name, $scope.inputDate2.mobile, $scope.inputDate2.chargeMoney2);
                                    }
                                    $scope.oilHistoryShow = false;

                                }
                            } else {
                                $scope.popAlert(data.resultMessage);
                            }


                        })
                        .error(function (data, status, headers, config) {
                            $scope.popAlert('网络错误！');
                        })
                }
            }
            $scope.delete = function (x, type) {
                $scope.oilHistoryShow = !$scope.oilHistoryShow;
                var dic = {
                    'apiName': 'life.delefulehistory',
                    'dele_id': x,
                    'type': type
                };
                $scope.loadingBox = true;
                $http(httpurl(dic))
                    .success(function (data) {
                        $scope.loadingBox = false;
                        if (data.resultCode == 0000) {
                            $scope.popAlert('删除成功');
                        } else {
                            $scope.popAlert(data.resultMessage);
                        }
                    })
                    .error(function (data, status, headers, config) {
                        $scope.popAlert('网络错误！');
                    })
            }
            $scope.chargeKeyup1 = function (cardNum1, name, mobile, chargeMoney1) {
                if (cardNum1.substring(0, 1) != 9) {
                    $scope.popAlert('请输入有效的中石油油卡号！');
                } else if (cardNum1.length == 16 && name != '' && myreg.test(mobile) && (chargeMoney1 > 50 && chargeMoney1 < 10000)) {
                    $scope.toPayBtn1 = 'btnSureT10';
                } else {
                    $scope.toPayBtn1 = 'btnT10';
                }
            }
            $scope.chargeKeyup2 = function (cardNum2, name, mobile, chargeMoney2) {
                if (cardNum2.substring(0, 8) == 10001131) {
                    $scope.chargeMoneyShow = true;
                    $scope.oilTwoBoxShow = false;
                    for (var i = 0; i < 3; i++) {
                        $scope.oilBtn[i] = 'oilBtn';
                    }
                    chargeMoney = undefined;
                    chargeType = '50_10000'
                } else if (cardNum2.length > 8) {
                    $scope.chargeMoneyShow = false;
                    $scope.oilTwoBoxShow = true;
                    chargeType = '500'
                }
                if (cardNum2.length == 19 && name != '' && myreg.test(mobile) && (chargeMoney2 >= 50 && chargeMoney2 <= 10000 || chargeMoney != undefined)) {
                    $scope.toPayBtn2 = 'btnSureT10';
                } else {
                    $scope.toPayBtn2 = 'btnT10';
                }
            }
            $scope.billCharge = function (cardNum, name, mobile, price) {
                if (chargeType == '500' && oilType == 2) {
                    price = chargeMoney;
                }
                if ($scope.toPayBtn2 == 'btnSureT10') {
                    var dic = {
                        'apiName': 'life.fulecard',
                        'cardNo': cardNum,
                        'mobile': mobile,
                        'money': price,
                        'cardname': name
                    };

                    $scope.loadingBox = true;
                    $http(httpurl(dic))
                        .success(function (data) {
                            $scope.loadingBox = false;

                            if (data.resultCode == 0000) {
                                wechatpay(data.result.id)
                            } else {
                                $scope.popAlert(data.resultMessage);
                            }
                        })
                        .error(function (data, status, headers, config) {
                            $scope.popAlert("网络错误！");
                        })
                }
            }
        })
})(angular);
